﻿using System;
using Microsoft.ML;
using Microsoft.ML.Runtime.Api;
using Microsoft.ML.Runtime.Data;
using Microsoft.ML.Runtime.Learners;
using Microsoft.ML.Transforms.Conversions;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Movies4UML
{
    class Program
    {
        public class MovieData
        {
            public float Y1990;
            public float Y2000;
            public float Y2010;
            public float Hebrew;
            public float English;
            public float Arabic;
            public float Romance;
            public float Comedy;
            public float Drama;
            public string Label;
        }

        public class MoviePrediction
        {
            [ColumnName("PredictedLabel")]
            public string PredictedLabels;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("1990's:");
            float Y1990Flag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("2000's:");
            float Y2000Flag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("2010's:");
            float Y2010Flag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("Hebrew:");
            float HebrewFlag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("English:");
            float EnglishFlag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("Arabic:");
            float ArabicFlag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("Romance:");
            float RomanceFlag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("Comedy:");
            float ComedyFlag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            Console.WriteLine("Drama:");
            float DramaFlag = float.Parse(Console.ReadKey().KeyChar.ToString());
            Console.WriteLine();

            var mlContext = new MLContext();

            string dataPath = "Prediction.txt";

            var reader = mlContext.Data.TextReader(new TextLoader.Arguments()
            {
                Separator = ",",
                HasHeader = true,
                Column = new[]
                {
                    new TextLoader.Column("Y1990", DataKind.R4, 0),
                    new TextLoader.Column("Y2000", DataKind.R4, 1),
                    new TextLoader.Column("Y2010", DataKind.R4, 2),
                    new TextLoader.Column("Hebrew", DataKind.R4, 3),
                    new TextLoader.Column("English", DataKind.R4, 4),
                    new TextLoader.Column("Arabic", DataKind.R4, 5),
                    new TextLoader.Column("Romance", DataKind.R4, 6),
                    new TextLoader.Column("Comedy", DataKind.R4, 7),
                    new TextLoader.Column("Drama", DataKind.R4, 8),
                    new TextLoader.Column("Label", DataKind.Text, 9)
                }
            });

            IDataView trainingDataView = reader.Read(new MultiFileSource(dataPath));

            var pipeline = mlContext.Transforms.Categorical.MapValueToKey("Label")
                .Append(mlContext.Transforms.Concatenate("Features", "Y1990", "Y2000", "Y2010", "Hebrew", "English", "Arabic", "Romance", "Comedy", "Drama"))
                .Append(mlContext.MulticlassClassification.Trainers.StochasticDualCoordinateAscent(label: "Label", features: "Features"))
                .Append(mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

            var model = pipeline.Fit(trainingDataView);

            var prediction = model.MakePredictionFunction<MovieData, MoviePrediction>(mlContext).Predict
            (
                new MovieData()
                {
                    Y1990 = Y1990Flag,
                    Y2000 = Y2000Flag,
                    Y2010 = Y2010Flag,
                    Hebrew = HebrewFlag,
                    English = EnglishFlag,
                    Arabic = ArabicFlag,
                    Romance = RomanceFlag,
                    Comedy = ComedyFlag,
                    Drama = DramaFlag,
                }
            );

            Console.WriteLine($"Predicted Movie type is: {prediction.PredictedLabels}");

            string filePath = @"C:\\Users\\Chen Algrabli\\Desktop\\Prediction.txt";

            string strComponents = Y1990Flag + ".0, " +
                        Y2000Flag + ".0, " +
                        Y2010Flag + ".0, " +
                        HebrewFlag + ".0, " +
                        EnglishFlag + ".0, " +
                        ArabicFlag + ".0, " +
                        RomanceFlag + ".0, " +
                        ComedyFlag + ".0, " +
                        DramaFlag + ".0, ";

            string strComponentToSearch = strComponents.Trim();
            string[] fileContent = System.IO.File.ReadAllLines(filePath);
            bool bFound = false;
            foreach (string line in fileContent)
            {
                if (line.Contains(strComponentToSearch))
                {
                    Console.WriteLine("100% Match!");
                    bFound = true;
                    break;
                }

            }
            if (!bFound)
            {

                Console.WriteLine("Does It The Best Fit Movie? Y/n");
                char Answer = Console.ReadKey().KeyChar;
                Console.WriteLine();

                if (Answer == 'Y')
                {
                    File.AppendAllText(filePath,
                        Environment.NewLine +
                        strComponents + ", " +
                        prediction.PredictedLabels
                        );
                    Console.WriteLine("Thanks!");
                }
                else if (Answer == 'n')
                {
                    Console.WriteLine("Insert Wanted Movie Name And You'll Learn For Next Time :)");
                    string movieName = Console.ReadLine().Trim();
                    bFound = false;
                    foreach (string line in fileContent)
                    {
                        if (line.Contains(movieName))
                        {
                            string[] strFound = line.Split(',');
                            string movieFullName = strFound[strFound.Length - 1].Remove(0, 1);
                            File.AppendAllText(filePath,
                            Environment.NewLine +
                            strComponents + ", " +
                            movieFullName);
                            Console.WriteLine("Noted, Thanks!");
                            bFound = true;
                            break;
                        }

                    }
                    if (!bFound)
                    {
                        Console.WriteLine("Unfortunately, Not Found, See You Next Time!");
                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine("Press 'Enter' For Exit");
            Console.ReadLine();
        }
    }
}

